from cmd import Cmd
import os
import sys
import time
import easygui
import random
import webbrowser


class Client(Cmd):
    """
    help
    仿dos
    """
    prompt = '/'
    intro = 'Minecraft File Converters(MCFC) Dos Edition 1.0_01 alpha\n   (C)Copyright As Genghis khan 2022-?'

    def __init(self):
        reload(sys)
        sys.setdefaultencoding('utf-8')
        Cmd.__init__(self)

    def do_hello(self, arg):
        if arg == 'MCFC-DOS':
            easygui.msgbox('恭喜你发现MCFC-DOS的彩蛋', 'MCFC-DOS', '继续')
            if easygui.ynbox('是否继续？', 'MCFC-DOS', ('是', '否')):
                sys.path.append("libs")
                url = 'http://classic.minecraft.net'
                webbrowser.open(url)
                print(webbrowser.get())
            else:
                pass
        else:
            print('hello', arg)

    def do_time(self, arg):
        print(time.ctime())

    def do_version(self, arg):
        easygui.msgbox('MCFC-DOS版本：1.0_01 alpha\nMade by As Genghis khan',
                       '关于MCFC-DOS', '确定')

    def do_make(self, arg):
        if arg == 'bat':
            f = os.getcwd()
            f1 = f.split('\\')
            f2 = open('{}.bat'.format(input('Save as:')),'w')
            f2.write('@ echo off\n{}\ncd {}\nstart python MCFC-DOS.py\nexit'.format(f1[0], f))
            f2.close()
        if arg == 'cmd':
            f = os.getcwd()
            f1 = f.split('\\')
            f2 = open('{}.cmd'.format(input('Save as:')), 'w')
            f2.write('@ echo off\n{}\ncd {}\nstart python MCFC-DOS.py\nexit'.format(f1[0], f))
            f2.close()
        else:
            print('Error! /make _⬅[here]')

    def do_quit(self, arg):
        print('Thanks you to use MCFC-DOS')
        return True  # 返回True，直接输入quit命令将会退出

    def do_options(self, arg):
        os.system('python options.py')

    def do_start(self, arg):
        if arg == 'CFC':
            time.sleep(0.01)
            os.system('python classic文件转换器.py')
        elif arg == 'IFC':
            time.sleep(0.01)
            os.system('python indev文件转换器.py')
        else:
            print('Error! /start _⬅[here]')

    def preloop(self):
        print("starting MCFC-DOS...")
        time.sleep(random.randint(1, 5))

    def postloop(self):
        # print 'Bye!'
        print("Bye!")

    def emptyline(self):
        time.sleep(.25)
        print('Unknown command. Try /help for a list of commands. \n')

    def default(self, line):
        time.sleep(.25)
        print('Unknown command. Try /help for a list of commands. \n')


if __name__ == '__main__':
    try:
        os.system('cls')
        client = Client()
        client.cmdloop()
    except:
        exit()
